# CrowdStrike Falcon Telemetry Parser

This package contains the parser for Falcon telemetry data. 

The related FLTR content can be found in the `crowdstrike/fltr-core` package. 

# Important and Breaking Changes

**This package is being reduced to only include the parser. Please use the `crowdstrike/fltr-core` package for non-parser content.**

Follow the [`crowdstrike/fltr-core` installation instructions](https://github.com/CrowdStrike/logscale-community-content/wiki/FLTR-Setup-and-Configuration) to get going.

If you've made modifications to the `crowdstrike/fdr` package contents and wish to keep them, they can be exported by going to `Settings -> Create a Package -> Export Package`.

# Changelog

`1.1.4`
- Disabled the FDR scheduled query by default. 
- Removed the PrintNightmare alert. 
- Added notices to the dashboards and queries about the migration to the `crowdstrike/fltr-core` package. 
- Added a dashboard with the migration notice. 
- Updated the README to remove older product references. 

`1.1.3`
- Fixes for the `#streamingApiEvent` tag on certain events. 

`1.1.2`
- The parser has been updated to assign the values of `ExternalApiType`, `eventType`, and `name` to a new tagged field `#streamingApiEvent`. This is done to speed up searching for these particular event types. For example, when previously searching for `ExternalApiType=Event_DetectionSummaryEvent`, it was recommended to also include `#event_simpleName!=*` since it was missing an event-specific tag. You would now do `#streamingApiEvent=Event_DetectionSummaryEvent`.
- Added fixes for timestamps related to Mobile and Cloud detection events.
- Aliased `AgentIdString` to `aid` when `AgentIdString` is present but `aid` is missing. 

`1.1.1`
- Changed parser to setting missing timestamps to the current time
- Added support for field ExternalApiType to be spelled as ExternalAPIType
- Changed parser to support FDR events that do not include @path information

`1.1.0`
- Added aidmaster scheduled search and action
- Changed parser to identify secondary data from FDR feeds that use CID aggregation
- Rewrote saved queries to use aidmaster lookup
- Revised dashboards, rewrote queries to use aidmaster lookup

`1.0.4`
- Changed some searches to require at least one of their parameters to be specified
- Changed parser to create a kind field on all events, containing the value 'Primary'or 'Secondary'
- Removed AGENT_LIST saved query

`1.0.3`
- Rewritten the queries to use groupBy instead of joins.
- Updated parser
- Added File Vantage, Process Context Events, and Software Invenctory dashboards

`1.0.2` 
- Dashboard query improvements and additional summary tables.

`1.0.1` 
- Update parser (and agent_list query) to use aid_master from Secondary Data. Changed the throttle time of the `PrintNightmare POC` alert to 24 hours to match the search interval.

`1.0.0` 
- Polished the parser and updated README to describe the new FDR integration in LogScale.

# Package Contents

## Parser

Whilst the events from FDR are structured (JSON), using this parser ensures that event timestamps are parsed correctly, and that the event fields `cid` and `event_simpleName` are used as tags.

## Dashboards

There is a selection of dashboards for getting quick value from your FDR data. These may serve as the basis for building custom FDR dashboards, alerts and queries to match your specific use case.

## Alerts and Saved Queries

The package provides alerts and saved queries. These are updated regularly and either provide specific detections (e.g. `PrintNightmare`) or more general use cases (e.g. `Failed Logons`).

# Use Case

- SecOps

# Support

For support please contact LogScale Support through the CrowdStrike support portal.

# Dependencies

The only dependency for this package is that Falcon data is being ingested into LogScale. This is done automatically in FLTR deployments. Other deployments will need to use the [FDR ingest method](https://library.humio.com/data-analysis/ingesting-data-fdr-repo.html). 

# Installation

Install this package in the repository containing Falcon data.
